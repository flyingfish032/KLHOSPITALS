import React from "react";
import DoctorsSection from "../Doctors/DoctorsSection";
// import ContactSection from "../Doctors/ContactSection";
// import Footer from "../Doctors/Footer";

const DoctorsCombined = () => {
  return (
    <>
      <DoctorsSection />
      {/* <ContactSection /> */}
      {/* <Footer /> */}
    </>
  );
};

export default DoctorsCombined;
